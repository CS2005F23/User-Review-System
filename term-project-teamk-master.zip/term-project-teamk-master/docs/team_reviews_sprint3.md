## Team Review

### Mahad's Team Review:

The semester is finally coming to a close and I can say that working with this team has been a great learning experience for me. I have learnt a lot
over these past few months and despite a few hiccups here and there, the team has come a long way since the first sprint. We work together very efficiently now and
if given the chance I would love to work with all of these guys again in the future as well.

Jason: Jason has been the leader of this team and has always taken an initiative with distributing tasks and getting things done. He always does his best to ensure everyone is on the same page 
and goes out of his way to help out each one of us. Being very honest I don't think Jason had any issues whatsoever this sprint, the only thing being of concern was a few days where he was unable to get work done due
to extreme workload outside of school and other courses. However, that was not an issue either given that the professor extended the deadline for the final sprint. Jason has been very active on discord as well and
always does his best to prepare for meetings beforehand so, he can ensure that everyone knows what they are doing. He has been this team's backbone and I believe that he will reach great heights in the future.

Zawad: Zawad has definitely shown the most improvement out of all members of this team. He was more regular in meetings and tried to be more interactive. He got all of his tasks done, but was a little behind the schedule we discussed, but again the professor
extended the deadline so, it worked out in the end. The only thing I feel he lacked was taking an initiative with tasks he wanted to do. He did do everything assigned to him, but he never pointed out that he wanted to do something which he was particularly interested in
or wanted to learn about. However, Jason was good with task division and I feel like everyone got to do a bit of everything and I believe Zawad feels the same way.

Md Gulam Mahmud Chowdhury (Dayeem): As I have always said Dayeem is this teams most punctual member and never disappoints us. He always pulls through with tasks and has definitely been 
more involved in the decision making process compared to earlier sprints. He blended together with the team more comfortably and got his tasks done flawlessly. Again the only problem, being extremely honest, we faced was that he ran a little bit behind our discussed schedule,
 but everything worked out with the professor providing us an extenison.

All in all, it has been an absolute pleasure working with these people and I wish them all the best for the future.

### Jason's Team Review:

**Team:**
The team has worked great together since the beginning. I feel like we came together and built a great first project for some of us. It was fun to build and fun to learn how to work as a team.

**Md Golam Mahmud (Dayeem):**
Dayeem has been great to work with, he always shows up to meetings on time and works hard on his tasks assigned to him.
Only suggestion for dayeem in the future would to be more vocal and also be more of a leader. I feel like he has the skills, just needs to confidence. Other than that, Dayeem has been a pleasure to work with. 

**Mahad:**
Mahad is great. He came up with a really good feature idea for this sprint and executed it very well. Still having a similar issue with not showing up to meetings on time though. It causes a slow down with our meetings and meetingnotes because we need the whole teams impact which results from us talking on discord more.

**Zawad (Tazwar):**
Zawad came up with a great idea for a feature this sprint. He did a great job on it as well, and I am happy with his work throughout the course. I gave him a bigger task of the microservices document and he did it very well.
Still having an issue with showing up on time for meetings though. And I would have liked his coding portion done sooner when the rest of us were working on ours. It would have allowed him to help with more documentation.

### Jawad's Team Review:
It has been a great experience to work as a team in this course. Learned a lot of things which improved me socially and personally. Each team member has performed exceptionally well. The last sprint and this sprint was really packed with true team effort. I really feel fortunate to have been a part of such a great group.
Now some words for my teammates:

**Jason:**
Jason is a great team leader, organizing tasks well and preparing thoroughly for meetings, which has really helped the team. His personal meetings with the course professor also cleared out a lot of doubts. But sometimes his other commitments affected his work with the team. It would be good if he shared tasks with others more.

**Dayeem:**
Dayeem is always on time and does his tasks well. He's good at making decisions and fits in well with the team. Although, he should try to finish tasks on the original schedule, even though he managed okay with the extended deadlines.

**Mahad:**
Mahad has good technical skills and his ideas for the project are really helpful. But he needs to be on time for meetings to help the team run smoothly.


### Md Golam Mahmud's Team Review:

The final sprint, had lots of challenges from the previous as we were making our application more specified according to the assignment specification. Our team experienced had to go in discussions for implementing features, time management and methods of implementing them. The team was very upbringing for new ideas and how to accomplish the goals. Each team member's became very specialized in performing tasks that they were supposed to do. Jason very innovative and efficient in HTML, Mahad in Database and information, Zawad in Documentation and project architecture and me at Backend and Applications. Here's a snapshot of my team member's performances for sprint 3:

**Jason:**
Jason has put up with his reputation. He has made the project objectives very clear from the start of the sprint. Team progress and due dates have been all tracked by him. Distributing tasks was far easier this time, as he knew what potentials each team members had. He also managed to distribute the tasks so that each team member is not put up with too much pressure. He has leaded the team in a very effective and efficient way.

Challenges: 
Jason found it hard to manage time schedules for others. Many team members including me were not able to finish the coding process on time. Although much decision-making and time enforcement. This had implications on Jason's work as he saw everyone else weren't putting enough efforts.

Response: 
Jason as a team member had to reinforce dates and persuade and navigate other team members on how to complete the tasks quicker and as specified.

**Mahad:**
Mahad's as usual was very keen on completing his tasks perfectly. He has the solutions to everything. His idea of using SendGrid made most of our tasks for the features work. His technical expertise had managed to finish tasks on time and even help other team members to do so. He was done with his job before anyone else.

Challenges: 
His communication was vague with the team. He was not very early in the team meetings

Response:
Proper messages and discussions were set at the discord team server to ensure that he is keeping up with the team progress.
Meeting note takers' follow-up with each team member after each meeting to ensure, nothing's missed throughout the project phase.

**Zawad:**
Zawad showed very enthusiastic work approach this sprint. He was very professional and powerful in doing the microservices document. He finished it in due time and provided very strong work dynamics this sprint. He has improved from last sprint, coming to team meetings in time, and understanding team prospects and decisions. 

Challenges:
Zawad mistook one of his feature updates in one instance. He couldn't understand what was wanted from him when he to code the feature for the top reviewer. He later understood in the next meeting. 

Response: 
He discussed his approach in the exact team meeting and finished his code without any further delay and not putting the team on stop for his work.
