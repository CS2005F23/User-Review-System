**Written by:** Mahad Mirza

As a computer science student using the review website, after submitting my review, I want to be able to view, edit, or delete the content of my review. Currently, this functionality is not available on the website. 
After I submit a review, there should be an option in the user dashboard to view my submitted reviews. When I select a specific review, I should be able to see the review content along with the title and any associated details.
I should have the option to edit the review, including modifying the title and content. I should also be able to delete the review if I decide to remove it from the system.

**Written by:** Jason Wheeler
I want to be able to login and have my own session. Once I login my profile and reviews should all be associated with myself. I want to be able to create new reviews and come back and see them later.


**Written by:** Md Golam Mahmud Chowdhury - 
As a computer science student, I wish to have a platform where I can easily review and discuss potential project prospects with my fellow students. I desire a feature-rich platform that allows us to list and categorize project ideas, provide detailed descriptions, and receive feedback and comments from peers. This will enable us to brainstorm, evaluate, and refine project concepts collaboratively, fostering innovation and meaningful discussions within our academic community.

**Written by:** Md Jawad Ul Tazwar
I think the current platform should have an option where I could view the reviews from other people besides my personal reviews. Apart from this, I want to have a feature where we can give anonymous reviews.